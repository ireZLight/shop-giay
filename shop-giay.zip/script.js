const products = [
    { id: 1, name: "Nike Air Force 1", price: 2500000, img: "https://via.placeholder.com/300x200?text=Nike+Air+Force+1" },
    { id: 2, name: "Nike Air Max", price: 3200000, img: "https://via.placeholder.com/300x200?text=Nike+Air+Max" },
    { id: 3, name: "Nike Jordan 1", price: 4500000, img: "https://via.placeholder.com/300x200?text=Nike+Jordan+1" },
    { id: 4, name: "Nike Cortez", price: 2200000, img: "https://via.placeholder.com/300x200?text=Nike+Cortez" }
];

let cart = [];

const productList = document.getElementById("product-list");
const cartCount = document.getElementById("cart-count");
const cartBox = document.getElementById("cart-box");
const cartItems = document.getElementById("cart-items");
const totalPrice = document.getElementById("total-price");
const clearCartBtn = document.getElementById("clear-cart");

// Render sản phẩm
products.forEach(product => {
    const div = document.createElement("div");
    div.classList.add("product");
    div.innerHTML = `
        <img src="${product.img}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>${product.price.toLocaleString()}₫</p>
        <button onclick="addToCart(${product.id})">Thêm vào giỏ</button>
    `;
    productList.appendChild(div);
});

// Thêm vào giỏ
function addToCart(id) {
    const product = products.find(p => p.id === id);
    cart.push(product);
    updateCart();
}

// Cập nhật giỏ hàng
function updateCart() {
    cartCount.textContent = cart.length;
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;
        const li = document.createElement("li");
        li.innerHTML = `
            ${item.name} - ${item.price.toLocaleString()}₫ 
            <button onclick="removeFromCart(${index})">❌</button>
        `;
        cartItems.appendChild(li);
    });

    totalPrice.textContent = total.toLocaleString();
}

// Xóa sản phẩm khỏi giỏ
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}

// Xóa toàn bộ giỏ
clearCartBtn.addEventListener("click", () => {
    cart = [];
    updateCart();
});

// Hiển thị / Ẩn giỏ hàng
document.querySelector(".cart").addEventListener("click", () => {
    cartBox.style.display = cartBox.style.display === "block" ? "none" : "block";
});